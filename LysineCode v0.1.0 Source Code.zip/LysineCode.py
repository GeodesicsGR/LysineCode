# Import Functions
import re
import PyQt5
import pygame

tokens = []
var_append = 0
error_message = ""  # ← New: holds syntax error to display

#----------------------------------------------------------------------------------------------------------------------

# Lexer function to tokenize input
def lexer(code):
    global tokens
    tokens = []
    token_specs = [
        ('ONELINE_DOUBLE_EXCLAMATION', r'!![^\n]*!!'),  # NEW: single-line !! ... !!
        ('DOUBLE_EXCLAMATION', r'!!'),
        ('EXCLAMATION',        r'![^\n]*'),  # Single-line comment starting with ! 
        ('NUMBER',             r'\d+(\.\d*)?'),
        ('PLUS',               r'\+'),
        ('MINUS',              r'\-'),
        ('MULTIPLY',           r'\*'),
        ('DIVIDE',             r'/'),
        ('ASSIGN',             r'='),
        ('END',                r';'),
        ('ID',                 r'[A-Za-z_][A-Za-z0-9_]*'),
        ('COMMA',               r','),
        ('DOT',                r'\.'),
        ('LPAREN',             r'\('),
        ('RPAREN',             r'\)'),
        ('STRING',             r'"[^"]*"'),
        ('NEWLINE',            r'\n'),
        ('SKIP',               r'[ \t]+'),
        ('ERROR',              r'.'),  # Catch unexpected characters
    ]
    token_regex = '|'.join(f'(?P<{name}>{pattern})' for name, pattern in token_specs)

    in_multiline_comment = False
    line_num = 1
    line_start = 0

    for match in re.finditer(token_regex, code):
        kind = match.lastgroup
        value = match.group()
        column = match.start() - line_start

        if kind == 'NEWLINE':
            line_num += 1
            line_start = match.end()
            if not in_multiline_comment:
                tokens.append((kind, value))
            continue
        elif kind == 'SKIP':
            continue
        elif kind == 'ONELINE_DOUBLE_EXCLAMATION':
            continue  # Skip this whole line
        elif kind == 'DOUBLE_EXCLAMATION':
            in_multiline_comment = not in_multiline_comment
            continue
        elif in_multiline_comment or kind == 'EXCLAMATION':
            continue  # Skip lines or tokens inside comments
        elif kind == 'ERROR':
            raise SyntaxError(f"Unexpected character: {value!r} at line {line_num}, column {column + 1}")
        tokens.append((kind, value))
    return tokens

#----------------------------------------------------------------------------------------------------------------------

variables = []
var_name = "Default"
var_value = "Default"

def execute(tokens):
    global var_name, var_value, var_append, variables, ig, result
    i = 0
    error_printed = False
    run_ex1 = False

    filtered_tokens = [t for t in tokens if t[0] not in ('SKIP', 'NEWLINE')]
    inside_multiline_comment = False

    while i < len(filtered_tokens):
        token_type, token_value = filtered_tokens[i]

        # Multiline comment handling
        if token_type == "EXCLAMATION2":
            inside_multiline_comment = not inside_multiline_comment
            i += 1
            continue

        if inside_multiline_comment:
            i += 1
            continue

        # Print values via output.return(...)
        if (
            i + 5 < len(filtered_tokens) and
            filtered_tokens[i][0] == "ID" and filtered_tokens[i][1] == "output" and
            filtered_tokens[i+1][0] == "DOT" and
            filtered_tokens[i+2][0] == "ID" and filtered_tokens[i+2][1] == "return" and
            filtered_tokens[i+3][0] == "LPAREN" and
            filtered_tokens[i+5][0] == "RPAREN"
        ):
            val_token = filtered_tokens[i+4]
            if val_token[0] == "STRING":
                print(val_token[1][1:-1])
            elif val_token[0] == "ID":
                variable_to_recall = val_token[1].lower()
                found = False
                for vn, vv in variables:
                    if vn == variable_to_recall:
                        print(vv)
                        found = True
                        break
                if not found:
                    print("Not Found")
            elif val_token[0] == "NUMBER":
                print(val_token[1])
            else:
                print("Unprintable String")

            i += 6
            continue

        # Simple math expression: 5 + 2
        if (
            i + 2 < len(filtered_tokens) and
            filtered_tokens[i][0] == "NUMBER" and
            filtered_tokens[i+1][0] in ("PLUS", "MINUS", "MULTIPLY", "DIVIDE") and
            filtered_tokens[i+2][0] == "NUMBER"
        ):
            num_1 = float(filtered_tokens[i][1])
            num_2 = float(filtered_tokens[i+2][1])
            op = filtered_tokens[i+1][0]

            if op == "PLUS":
                result = num_1 + num_2
            elif op == "MINUS":
                result = num_1 - num_2
            elif op == "MULTIPLY":
                result = num_1 * num_2
            elif op == "DIVIDE":
                result = num_1 / num_2

            print(result)
            i += 3
            continue
        
        # Simple math: var x = 5 + 2
        if (
            i + 5 < len(filtered_tokens) and
            filtered_tokens[i][0] == "ID" and filtered_tokens[i][1] == "var" and
            filtered_tokens[i+1][0] == "ID" and
            filtered_tokens[i+2][0] == "ASSIGN" and
            filtered_tokens[i+3][0] == "NUMBER" and
            filtered_tokens[i+4][0] in ("PLUS", "MINUS", "MULTIPLY", "DIVIDE") and
            filtered_tokens[i+5][0] == "NUMBER"
        ):
            num1 = float(filtered_tokens[i+3][1])
            num2 = float(filtered_tokens[i+5][1])
            operator = filtered_tokens[i+4][0]

            if operator == "PLUS":
                result = num1 + num2
            elif operator == "MINUS":
                result = num1 - num2
            elif operator == "MULTIPLY":
                result = num1 * num2
            elif operator == "DIVIDE":
                result = num1 / num2

            var_name = filtered_tokens[i+1][1]
            var_value = str(result)
            var_append = (var_name, var_value)
            variables.append(var_append)
            run_ex1 = True
            i += 6
            continue

        # Variable assignment: var x = y
        if (
            i + 3 < len(filtered_tokens) and
            filtered_tokens[i][0] == "ID" and filtered_tokens[i][1] == "var" and
            filtered_tokens[i+1][0] == "ID" and
            filtered_tokens[i+2][0] == "ASSIGN" and
            run_ex1 == False
        ):
            var_name = filtered_tokens[i+1][1].lower()

            # Simple direct value (string or number)
            if filtered_tokens[i+3][0] in ("STRING", "NUMBER"):
                var_value = filtered_tokens[i+3][1]
                var_append = (var_name, var_value)
                variables.append(var_append)
                i += 4
                continue

        # round(number, places)
        if (
            i + 4 < len(filtered_tokens) and
            filtered_tokens[i][0] == "ID" and filtered_tokens[i][1] == "round" and
            filtered_tokens[i+1][0] == "LPAREN" and
            filtered_tokens[i+2][0] == "NUMBER" and
            filtered_tokens[i+3][0] == "COMMA" and
            filtered_tokens[i+4][0] == "NUMBER"
        ):
            num = float(filtered_tokens[i+2][1])
            places = int(filtered_tokens[i+4][1])
            result = round(num, places)
            print(result)
            i += 5
            continue

        # Single-line comment
        if token_type == "EXCLAMATION":
            i += 1
            while i < len(filtered_tokens) and filtered_tokens[i][0] not in ('DOUBLE_SLASH_CMD', 'SLASH_CMD', 'ID'):
                i += 1
            continue

        if not error_printed:
            print("Not Recognized")
            error_printed = True
        i += 1

def slcode(tokens):
    global var_name, var_value, var_append, variables, ig, result
    i = 0

    filtered_tokens = [t for t in tokens if t[0] not in ('SKIP', 'NEWLINE')]
    inside_multiline_comment = False

    while i < len(filtered_tokens):
        token_type = filtered_tokens[i][0]

        if token_type == "EXCLAMATION2":
            inside_multiline_comment = not inside_multiline_comment
            i += 1
            continue

        if inside_multiline_comment:
            i += 1
            continue

        # Simple math
        if (
            i + 2 + ig < len(filtered_tokens) and
            filtered_tokens[i+ig][0] == "NUMBER" and
            filtered_tokens[i+1+ig][0] in ("PLUS", "MINUS", "MULTIPLY", "DIVIDE") and
            filtered_tokens[i+2+ig][0] == "NUMBER"
        ):
            num1 = float(filtered_tokens[i+ig][1])
            num2 = float(filtered_tokens[i+2+ig][1])
            op = filtered_tokens[i+1+ig][0]

            if op == "PLUS":
                result = num1 + num2
            elif op == "MINUS":
                result = num1 - num2
            elif op == "MULTIPLY":
                result = num1 * num2
            elif op == "DIVIDE":
                result = num1 / num2

            i += 3
            continue

        # round(num, places)
        elif (
            i + 4 + ig < len(filtered_tokens) and
            filtered_tokens[i+ig][0] == "ID" and
            filtered_tokens[i+ig][1] == "round" and
            filtered_tokens[i+1+ig][0] == "LPAREN" and
            filtered_tokens[i+2+ig][0] == "NUMBER" and
            filtered_tokens[i+3+ig][0] == "COMMA" and
            filtered_tokens[i+4+ig][0] == "NUMBER"
        ):
            num_to_round = float(filtered_tokens[i+2+ig][1])
            dec_place = int(filtered_tokens[i+4+ig][1])
            result = round(num_to_round, dec_place)
            i += 5
            continue

        i += 1

#----------------------------------------------------------------------------------------------------------------------

pygame.init()

multi_line = False

icon = pygame.image.load("D:\Python Code\LysineCode (peak).png")
pygame.display.set_icon(icon)

font_code = "D:\Python Code\JetBrainsMono-VariableFont_wght.ttf"
font_size_code = 20
font_main_code = pygame.font.Font(font_code, font_size_code)

codelines = [""]
text = font_main_code.render(codelines[0], True, (255, 255, 255))
text_rect = text.get_rect(topleft=(0, 0))  # Adjust position as needed

infoObject = pygame.display.Info()
screen_width = infoObject.current_w
screen_height = infoObject.current_h
screen = pygame.display.set_mode((screen_width, screen_height - 60))  # offset to keep window border

y_offset = 0
y_count = 0

margin_x = 20
max_width = screen_width - margin_x * 2
line_spacing = 30

running = True
while running:
    screen.fill((20, 20, 30))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_BACKSPACE:
                if len(codelines[-1]) > 0:
                    codelines[-1] = codelines[-1][:-1]
                else:
                    if len(codelines) > 1:
                        codelines.pop()
            elif event.key == pygame.K_RETURN:
                codelines.append("")
                y_count += 1

                code = "\n".join(codelines)
                try:
                    tokens = lexer(code)
                    execute(tokens)
                    error_message = ""  # ← Clear error if success
                except SyntaxError as e:
                    error_message = str(e)
            else:
                typed = event.unicode
                codelines[-1] += typed

    y_offset = 20
    comment_mode = False  # ← Persist across all lines this frame

    for line in codelines:
        stripped = line.strip()

        # Determine if line is part of a comment
        if stripped == "!!":
            is_comment = True
            multi_line = True
        elif stripped.startswith("!!") and stripped.endswith("!!") and len(stripped) > 4:
            is_comment = True
        if stripped.endswith("!!") and stripped != "!!":
            is_comment = True
            multi_line = False
        elif comment_mode:
            is_comment = True
        elif stripped.startswith("!"):
            is_comment = True
        elif multi_line == True:
            is_comment = True
        else:
            is_comment = False

        # Render wrapped lines with appropriate color
        words = line.split(' ')
        wrapped_line = ""
        for word in words:
            test_line = wrapped_line + word + ' '
            test_render = font_main_code.render(test_line, True, (100, 100, 100) if is_comment else (255, 255, 255))
            if test_render.get_width() <= max_width:
                wrapped_line = test_line
            else:
                text = font_main_code.render(wrapped_line, True, (100, 100, 100) if is_comment else (255, 255, 255))
                screen.blit(text, (margin_x, y_offset))
                y_offset += line_spacing
                wrapped_line = word + ' '
        if wrapped_line:
            text = font_main_code.render(wrapped_line, True, (100, 100, 100) if is_comment else (255, 255, 255))
            screen.blit(text, (margin_x, y_offset))
            y_offset += line_spacing

    # ← Show syntax error message at bottom
    if error_message:
        error_text = font_main_code.render(error_message, True, (255, 100, 100))
        screen.blit(error_text, (margin_x, y_offset + 10))

    pygame.display.flip()

pygame.quit()